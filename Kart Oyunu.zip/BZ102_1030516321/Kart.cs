﻿using System;
using System.Collections.Generic;
using System.Text;

namespace KartoyunuBZ102
{

    enum Renk
    {
        Mavi,
        Sari,
        Kirmizi
    }
    enum KartTipi
    {
        RenkDegistir,
        Normal
    }
    class Kart
    {
        public Renk Rnk { get; set; }
        public KartTipi Typ { get; set; }
        public int Num { get; set; }

        public void Goster()
        {
            if (this.Typ == KartTipi.Normal)
            {
                switch (this.Rnk)
                {
                    case Renk.Mavi:
                        Console.ForegroundColor = ConsoleColor.Blue;
                        break;
                    case Renk.Sari:
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        break;
                    case Renk.Kirmizi:
                        Console.ForegroundColor = ConsoleColor.Red;
                        break;
                    default:
                        break;
                }
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.White;
            }
            Console.WriteLine(this.ToString());
            Console.ForegroundColor = ConsoleColor.White;//Varsayılan değere dönmek için
        }
        public override string ToString()
        {
            if (Typ == KartTipi.Normal)
            {
                return $"{Rnk},{Num}";
            }
            else
            {
                return $"RenkDeğiştir";
            }
        }
    }
}
