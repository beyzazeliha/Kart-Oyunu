﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;

namespace KartoyunuBZ102
{
    class Program
    {
        private static List<Kart> Kartlistesi = new List<Kart>();
        private static Kart Yer = null;
        private static void InitGame()
        {
            //Normal kartları oluşturuyor
            foreach (Renk item in Enum.GetValues(typeof(Renk)))
            {
                for (int i = 1; i <= 5; i++)
                {
                    Kart kart = new Kart
                    {
                        Num = i,
                        Rnk = item,
                        Typ = KartTipi.Normal
                    };
                    Kartlistesi.Add(kart);
                }
            }
            //özel kartları oluşturuyor
            for (int i = 0; i < 3; i++)
            {
                Kart kart = new Kart {Typ = KartTipi.RenkDegistir };
                Kartlistesi.Add(kart);
            }
            //Kartlar karılıyor
            Kartlistesi = Kartlistesi.OrderBy(x => Guid.NewGuid()).ToList(); // Kaynak = https://improveandrepeat.com/2018/08/a-simple-way-to-shuffle-your-lists-in-c/
        }

        private static List<Oyuncu> OyuncuOlustur(string OyuncuAdi)
        {
            List<Oyuncu> Oyuncular = new List<Oyuncu>();
            for (int i = 0; i < 2; i++)//BOT oyuncular oluşturuluyor.
            {
                Oyuncu oyuncu = new Oyuncu()
                {
                    Name = $"BOT{i}",
                    Tip = OyuncuTipi.BOT,
                    Kartlar = Kartlistesi.GetRange(0,6)//kart listesindeki ilk 6 kart oyunculara veriliyor.
                };
                Kartlistesi.RemoveRange(0,6);//Oyuncuya veilen ilk 6 kart listeden siliniyor.
                Oyuncular.Add(oyuncu);
            }
            Oyuncu kullanici = new Oyuncu()
            {
                Name = OyuncuAdi,
                Tip = OyuncuTipi.Kullanici,
                Kartlar = Kartlistesi.GetRange(0, 6)
            };
            Kartlistesi.RemoveRange(0, 6);
            Oyuncular.Add(kullanici);
            Oyuncular = Oyuncular.OrderBy(x=> Guid.NewGuid()).ToList();//Oyuncuların hep aynı sırada oynamaması için lisste karılıyor.
            return Oyuncular;
        }
        static void Main()
        {
            Console.WriteLine("Hoşgeldiniz!!");
            Console.WriteLine("Yerdeki kart ile aynı renk ya da numaraya sahip bir kart veya ,elinizde varsa,\n" +
                "RenkDeğiştir kartını atmanız istenmektedir. Oyunda iki adet de Bot blunmaktadır.\n" +
                "Başlamak için bir tuşa basın...");
            Console.ReadKey();
            Basla();
        }
        public static bool devam = true;
        private static void Basla()
        {
            InitGame();
            Console.WriteLine("Lütfen isminizi giriniz:");
            string isim = Console.ReadLine();
            var Liste = OyuncuOlustur(isim);
            while (devam)
            {
                Oyna(Liste);
            }
        }
        public static void Oyna(List<Oyuncu> Liste)
        {
            foreach (var oyuncu in Liste)
            {
                
                if (Yer == null)
                {
                    Yer = KartIste(oyuncu,Yer);
                }
                else
                {
                    Kart Atilan = KartIste(oyuncu, Yer);
                    if (Atilan != null)
                    {
                        oyuncu.Kartlar.Remove(Atilan);//Atılan kart kullanıcının listesinden siliniyor.
                        switch (Atilan.Typ)
                        {
                            case KartTipi.RenkDegistir:
                                {
                                    Renk renk;
                                    Console.WriteLine($"{oyuncu.Name} Renk değiştirme kartı attı!");
                                    if (oyuncu.Tip == OyuncuTipi.Kullanici)
                                    {
                                        renk = oyuncu.KullaniciRenk();
                                    }
                                    else
                                    {
                                        renk = oyuncu.BotRenk();
                                    }
                                    Yer = new Kart()
                                    {
                                        Num = Yer.Num,
                                        Typ = KartTipi.Normal,
                                        Rnk = renk
                                    };
                                    Console.WriteLine($"{oyuncu.Name} {renk} rengini seçti!");
                                    break;
                                }

                            default:
                                if (Atilan.Rnk == Yer.Rnk || Atilan.Num == Yer.Num)//kartın yerdekiyle uyumu kontrol ediliyor
                                {
                                    Console.Write($"{oyuncu.Name}");
                                    Atilan.Goster();
                                    Yer = Atilan;
                                }
                                else
                                {
                                    Console.ForegroundColor = ConsoleColor.Red;//Hata Kırmızı renkle gösteriliyor
                                    Console.WriteLine("Yerdekiyle uyumsuz kart atamazsınız.\n" +
                                        "Lütfen yerdekiyle aynı renk ve ya numaralı kart atın ya da varsa RenkDeğiştir kartı atın");
                                    Console.ForegroundColor = ConsoleColor.White;//Console rengi varsayılan haline geri getiriliyor.
                                    KartIste(oyuncu, Yer);
                                }
                                break;
                        }
                    }
                    else
                    {
                        Console.WriteLine($"{oyuncu.Name} Pas dedi!");
                        continue;
                    }
                }
            }
        }
        private static Kart KartIste(Oyuncu oyuncu, Kart Yer)
        {
            if (Yer != null)
            {
                if (oyuncu.Tip == OyuncuTipi.Kullanici)
                {
                    return oyuncu.KullaniciOynat(Yer);
                }
                else
                {
                    return oyuncu.BotOynat(Yer);
                }
            }
            else
            {
                if (oyuncu.Tip == OyuncuTipi.Kullanici)
                {
                    return oyuncu.KullaniciOynatIlk();
                }
                else
                {
                    return oyuncu.BotOynat(Yer);
                }
            }
        }
    }
}
