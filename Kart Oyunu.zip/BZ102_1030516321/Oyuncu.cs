﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Threading.Tasks.Sources;
using System.Linq;

namespace KartoyunuBZ102
{
    enum OyuncuTipi
    {
        BOT,
        Kullanici
    }
    class Oyuncu
    {
        public string Name { get; set; }
        public List<Kart> Kartlar { get; set; }
        public OyuncuTipi Tip { get; set; }
        public void KartlariGoster()
        {
            foreach (var item in this.Kartlar)
            {
                item.Goster();
            }
        }
        public Kart KullaniciOynatIlk()
        {
            KartlariGoster();
            Kart kart = null;
            while (true)
            {
                string Giris = Console.ReadLine();
                if (Giris == "Pas")
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("İlk seferde Pas diyemezsiniz!!");
                    Console.ForegroundColor = ConsoleColor.White;
                    continue;
                }
                else
                {
                    foreach (var item in Kartlar)
                    {
                        if (item.ToString() == Giris)
                        {
                            kart = item;
                            break;
                        }
                    }
                    if (kart == null || kart.Typ == KartTipi.RenkDegistir)
                    {
                        Console.WriteLine("Lütfen geçerli bir kart giriniz. (Renk değiştirme kartı ile başlayamazsınız!!!)");
                        continue;
                    }
                    break;
                }
            }
            return kart;
        }
        public Kart KullaniciOynat(Kart Yerdeki)
        {
            //Console.Clear();

            if (this.Kartlar.Count == 0)
            {
                Console.WriteLine($"{this.Name} kazandı.");
                Program.devam = false;
                return null;
            }
            else
            {
                KartlariGoster();
                Console.WriteLine($"Yerdeki kart: {Yerdeki}");
                Kart kart = null;
                while (true)
                {
                    string Giris = Console.ReadLine();
                    if (Giris == "Pas")
                    {
                        kart = null;
                        break;
                    }
                    else
                    {
                        foreach (var item in Kartlar)
                        {
                            if (item.ToString() == Giris)
                            {
                                kart = item;
                                break;
                            }
                        }
                        if (kart == null)
                        {
                            Console.WriteLine("Lütfen geçerli bir kart giriniz.");
                            continue;
                        }
                        break;
                    }
                }
                return kart;
            }


        }
        public Kart BotOynat(Kart Yerdeki)
        {
            if (this.Kartlar.Count ==0)
            {
                Console.WriteLine($"{this.Name} kazandı.");
                Program.devam = false;
                return null;
            }
            else
            {
                Kart kart = null;
                if (Yerdeki != null)
                {
                    foreach (var item in Kartlar)
                    {
                        if (item.Rnk == Yerdeki.Rnk || item.Num == Yerdeki.Num)
                        {
                            kart = item;
                            break;
                        }
                        else
                        {
                            if (item.Typ == KartTipi.RenkDegistir)
                            {
                                kart = item;
                                break;
                            }
                        }
                    }
                }
                else
                {

                    Random rnd = new Random();
                    var GecerliKartlar = from x in this.Kartlar
                                         where x.Typ == KartTipi.Normal
                                         select x;
                    kart = GecerliKartlar.ToArray()[rnd.Next(0, GecerliKartlar.Count())];

                }

                return kart;
            }

        }
        public Renk KullaniciRenk()
        {
            Console.WriteLine("Renk giriniz: Kirmizi, Mavi ya da Sari");
            string giris = Console.ReadLine();
            Renk renk;
            switch (giris)
            {
                case "Kirmizi":
                    renk = Renk.Kirmizi;
                    break;
                case "Mavi":
                    renk = Renk.Mavi;
                    break;
                case "Sari":
                    renk = Renk.Sari;
                    break;
                default:
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Lütfen yukarıda verilen renklerden birini giriniz:");
                    Console.ForegroundColor = ConsoleColor.White;
                    renk = KullaniciRenk();
                    break;
            }
            return renk;
        }
        public Renk BotRenk()
        {
            Random rnd = new Random();
            int index = rnd.Next(1, 3);
            switch (index)//1 için kırmızı, 2 için Mavi, 3 için Sarı
            {
                case 1:
                    return Renk.Kirmizi;
                case 2:
                    return Renk.Mavi;
                default:
                    return Renk.Sari;
            }
        }
    }
}
